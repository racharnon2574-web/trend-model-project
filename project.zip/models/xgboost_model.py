from xgboost import XGBRegressor

def run_xgboost(X_train, y_train, X_test):

    model = XGBRegressor(

        n_estimators=3000,
        learning_rate=0.01,

        max_depth=8,
        min_child_weight=3,

        subsample=0.8,
        colsample_bytree=0.8,

        random_state=42
    )

    model.fit(X_train, y_train)

    pred = model.predict(X_test)

    return pred